import { ContentOptions } from '../options/content';
declare const initContent: (opts: ContentOptions) => void;
export default initContent;
