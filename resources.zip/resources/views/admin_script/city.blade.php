<script type="text/javascript">
    $(function() {
        var table = $('.data-table1').DataTable({
            processing: true,
            serverSide: true,
            ajax: "{{ route('city_page') }}",
            pageLength: 1000,
            buttons: ['copy', 'excel', 'pdf', 'print'],
            dom: 'Bfrtip',
            select: true,
            columns: [{
                    data: 'id',
                    name: 'id'
                },
                {
                    data: 'name',
                    name: 'name'
                },
                {
                    data: 'state.name',
                    name: 'state.name',

                },
                {
                    data: 'state.country.name',
                    name: 'state.country.name',

                },
                {
                    data: 'latitude',
                    name: 'latitude'
                },
                {
                    data: 'longitude',
                    name: 'longitude'
                },

            ]
        });
    });
</script>
